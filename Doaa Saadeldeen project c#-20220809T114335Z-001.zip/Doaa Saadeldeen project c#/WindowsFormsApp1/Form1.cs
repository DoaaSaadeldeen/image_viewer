﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Threading;

namespace WindowsFormsApp1
{

    public partial class Form1 : Form
    {
        string[] my_images;
        int cnt = 0;
        PictureBox picc;
        public Form1()
        {
            InitializeComponent();
            listBox1.SelectionMode = SelectionMode.None;
        }

        // uploading 
        private void uploadToolStripMenuItem_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            panel1.Controls.Clear();
            OpenFileDialog open;
            // add images names to list box
            open = new OpenFileDialog();
            open.Filter = "Image Files(*.jpg;*.jpeg;*.bmp;*.PNG;)|*.jpg;*.jpeg;*.gif;*.bmp;*.PNG;";
            open.Multiselect = true;
            if (open.ShowDialog() == DialogResult.OK)
            {
                my_images = open.FileNames;
                foreach (string my_image in my_images)
                {
                      listBox1.Items.Add(Path.GetFileName(my_image));
                }

            }
        }

         //slide show
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (cnt < my_images.Length - 1)
            {
                cnt++;
                statusBar1.Text = (Path.GetFileName(my_images[cnt]));
                picc.Image = Image.FromFile(my_images[cnt]);
                panel1.Controls.Add(picc);
                timer1.Start();
            }
            else
            {
                statusBar1.Visible = false;
                return;
            }
        }
        //  single mode
        private void single_mode_Click(object sender, EventArgs e)
        {
            listBox1.SelectionMode = SelectionMode.One;
            panel1.Controls.Clear();
        }
        //  slide mode
        private void slide_mode_Click(object sender, EventArgs e)
        {
            if (listBox1.Items.Count != 0)
            {
                panel1.Controls.Clear();
                statusBar1.Visible = true;
                listBox1.SelectionMode = SelectionMode.None;
                //picc
                picc = new PictureBox();
                picc.SizeMode = PictureBoxSizeMode.Zoom;
                Size size = picc.Size;
                size.Height = 360;
                size.Width = 460;
                picc.Size = size;
                timer1.Start();
                cnt = -1;
            }
        }
        //  multi mode
        private void multi_mode_Click(object sender, EventArgs e)
        {
            panel1.Controls.Clear();
            listBox1.SelectionMode = SelectionMode.MultiExtended;
        }
        //exit
        private void exit_btn_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }
        //when select any image from list box
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(listBox1.SelectionMode==SelectionMode.One)
            {
                panel1.Controls.Clear();
                //picc
                picc = new PictureBox();
                picc.SizeMode = PictureBoxSizeMode.Zoom;
                Size size = picc.Size;
                size.Height = 320;
                size.Width = 420;
                picc.Size = size;

                int index = listBox1.SelectedIndex;
                picc.Image = Image.FromFile(my_images[index]);

                panel1.Controls.Add(picc);
            }// multi mode 
            else if (listBox1.SelectionMode == SelectionMode.MultiExtended)
            {
                panel1.Controls.Clear();
                int y = 20, x = 20;
                int maxHeight = -1;
      
                foreach(int index in listBox1.SelectedIndices)
                {
                    PictureBox pic = new PictureBox();
                    pic.SizeMode = PictureBoxSizeMode.StretchImage;//.Zoom

                    Size size = pic.Size;
                    size.Height = 100;
                    size.Width = 150;
                    pic.Size = size;

                    pic.Image = Image.FromFile(my_images[index]);
                    pic.Location = new Point(x, y);
                    x += (pic.Width + 20);
                    maxHeight = Math.Max(pic.Height, maxHeight);
                    if (x + 190 > 520)  //150 for image and 20 left space  20 rigt space /
                    {
                        x = 20;
                        y += (maxHeight + 20);
                    }

                    this.panel1.Controls.Add(pic);
                }
            }
        }

        
    }
}
