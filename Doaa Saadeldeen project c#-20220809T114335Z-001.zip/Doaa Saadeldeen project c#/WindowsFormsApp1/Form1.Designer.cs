﻿
namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.statusBar1 = new System.Windows.Forms.StatusBar();
            this.panel1 = new System.Windows.Forms.Panel();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.my_context_menu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.uploadToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.single_mode = new System.Windows.Forms.ToolStripMenuItem();
            this.slide_mode = new System.Windows.Forms.ToolStripMenuItem();
            this.multi_mode = new System.Windows.Forms.ToolStripMenuItem();
            this.exit_btn = new System.Windows.Forms.ToolStripMenuItem();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.label1 = new System.Windows.Forms.Label();
            this.my_context_menu.SuspendLayout();
            this.SuspendLayout();
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 16;
            this.listBox1.Location = new System.Drawing.Point(617, 82);
            this.listBox1.Name = "listBox1";
            this.listBox1.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.listBox1.Size = new System.Drawing.Size(346, 404);
            this.listBox1.TabIndex = 0;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // statusBar1
            // 
            this.statusBar1.Location = new System.Drawing.Point(0, 549);
            this.statusBar1.Name = "statusBar1";
            this.statusBar1.Size = new System.Drawing.Size(1095, 43);
            this.statusBar1.TabIndex = 5;
            this.statusBar1.Text = "name of current image";
            this.statusBar1.Visible = false;
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Location = new System.Drawing.Point(59, 82);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(520, 400);
            this.panel1.TabIndex = 7;
          
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // my_context_menu
            // 
            this.my_context_menu.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.my_context_menu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.uploadToolStripMenuItem,
            this.single_mode,
            this.slide_mode,
            this.multi_mode,
            this.exit_btn});
            this.my_context_menu.Name = "single_m";
            this.my_context_menu.Size = new System.Drawing.Size(206, 124);
            // 
            // uploadToolStripMenuItem
            // 
            this.uploadToolStripMenuItem.Name = "uploadToolStripMenuItem";
            this.uploadToolStripMenuItem.Size = new System.Drawing.Size(205, 24);
            this.uploadToolStripMenuItem.Text = "upload";
            this.uploadToolStripMenuItem.Click += new System.EventHandler(this.uploadToolStripMenuItem_Click);
            // 
            // single_mode
            // 
            this.single_mode.Name = "single_mode";
            this.single_mode.Size = new System.Drawing.Size(205, 24);
            this.single_mode.Text = "single mode";
            this.single_mode.Click += new System.EventHandler(this.single_mode_Click);
            // 
            // slide_mode
            // 
            this.slide_mode.Name = "slide_mode";
            this.slide_mode.Size = new System.Drawing.Size(205, 24);
            this.slide_mode.Text = "slide show mode";
            this.slide_mode.Click += new System.EventHandler(this.slide_mode_Click);
            // 
            // multi_mode
            // 
            this.multi_mode.Name = "multi_mode";
            this.multi_mode.Size = new System.Drawing.Size(205, 24);
            this.multi_mode.Text = "multi picture mode";
            this.multi_mode.Click += new System.EventHandler(this.multi_mode_Click);
            // 
            // exit_btn
            // 
            this.exit_btn.Name = "exit_btn";
            this.exit_btn.Size = new System.Drawing.Size(205, 24);
            this.exit_btn.Text = "Exit";
            this.exit_btn.Click += new System.EventHandler(this.exit_btn_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Font = new System.Drawing.Font("Gloucester MT Extra Condensed", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.label1.Location = new System.Drawing.Point(70, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(863, 37);
            this.label1.TabIndex = 8;
            this.label1.Text = "right click  ,uplaod  ,then select mode  ... ( in case of single or multi mode se" +
    "lect picture(s) )";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.BackgroundImage = global::WindowsFormsApp1.Properties.Resources.download__2_;
            this.ClientSize = new System.Drawing.Size(1095, 592);
            this.ContextMenuStrip = this.my_context_menu;
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.statusBar1);
            this.Controls.Add(this.listBox1);
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Picture viewer";
            this.my_context_menu.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.StatusBar statusBar1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.ContextMenuStrip my_context_menu;
        private System.Windows.Forms.ToolStripMenuItem single_mode;
        private System.Windows.Forms.ToolStripMenuItem slide_mode;
        private System.Windows.Forms.ToolStripMenuItem multi_mode;
        private System.Windows.Forms.ToolStripMenuItem exit_btn;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.ToolStripMenuItem uploadToolStripMenuItem;
        private System.Windows.Forms.Label label1;
    }
}

